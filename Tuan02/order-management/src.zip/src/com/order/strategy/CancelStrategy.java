package com.order.strategy;

public class CancelStrategy implements ProcessStrategy {
    public void execute() {
        System.out.println("❌ Hủy đơn và hoàn tiền...");
    }
}