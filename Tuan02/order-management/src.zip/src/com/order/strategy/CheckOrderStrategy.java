package com.order.strategy;

public class CheckOrderStrategy implements ProcessStrategy {
    public void execute() {
        System.out.println("🔍 Kiểm tra thông tin đơn hàng...");
    }
}