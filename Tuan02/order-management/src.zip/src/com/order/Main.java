package com.order;

import com.order.context.OrderContext;
import com.order.state.CancelledState;
import com.order.state.NewState;

public class Main {
    public static void main(String[] args) {

        OrderContext order = new OrderContext();

        System.out.println("=== Đơn mới ===");
        order.setState(new NewState());
        order.process();

        System.out.println("\n=== Đang xử lý ===");
        order.process();

        System.out.println("\n=== Đã giao ===");
        order.process();

        System.out.println("\n=== Hủy đơn ===");
        order.setState(new CancelledState());
        order.process();
    }
}