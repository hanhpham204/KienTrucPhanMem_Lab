package com.order.decorator;

import com.order.strategy.ProcessStrategy;

public class InsuranceDecorator extends StrategyDecorator {

    public InsuranceDecorator(ProcessStrategy strategy) {
        super(strategy);
    }

    @Override
    public void execute() {
        super.execute();
        System.out.println("🛡️ Thêm bảo hiểm cho đơn hàng.");
    }
}